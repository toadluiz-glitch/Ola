﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho_de_Geo_Csharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Cidade Aripuanã MT, Mês:Maio
            //Fonte:https://pt.weatherspark.com/d/28812/5/1/Condi%C3%A7%C3%B5es-meteorol%C3%B3gicas-caracter%C3%ADsticas-de-Aripuan%C3%A3-Mato-Grosso-Brasil-em-1-de-maio
            double[,] Matriz =
            {
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                //4 dia
                {36,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                //11 dia
                {30,20,5,20 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                //27 dia
                {30,18,5,7 },
                {30,20,5,7 },
                {30,20,5,7 },
                {30,20,5,7 }
            };
            int ct, i, DiaMQ, DiaMF, DiaMC;
            double temp1, temp2, temp3;
            double MTempMa, MTempMi, MUmi, MPre;
            DiaMC = DiaMF = DiaMQ = 0;
            temp1 = Matriz[0, 0];
            temp2 = Matriz[0, 1];
            temp3 = Matriz[0, 3];
        inicio:
            MTempMa = MTempMi = MPre = MUmi = 0;
            Console.BackgroundColor = ConsoleColor.DarkGreen;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("=== Analise Climatica do Mês ===");
            Console.WriteLine("1. Médias do Mês");
            Console.WriteLine("2. Valores Extremos");
            Console.WriteLine("3. Distribuições");
            Console.WriteLine("4. Análises Avançadas");
            Console.WriteLine("5. Ordenação e Pesquisa");
            Console.WriteLine("6. Comparações Semanais");
            Console.WriteLine("7. Criatividade");
            Console.WriteLine("8. Sair");
            Console.Write("Digite a opção que deseja: ");
            int escolha = int.Parse(Console.ReadLine());
            do
            {
                if (escolha < 0 || escolha > 9)
                {
                    Console.Write("Opção Invalida, digite outra opção: ");
                    escolha = int.Parse(Console.ReadLine());
                }
            }
            while (escolha < 0 || escolha > 9);


            switch (escolha)
            {
                case 1:
                    Console.Clear();
                    for (ct = 0; ct < 30; ct++)
                    {
                        MTempMa += Matriz[ct, 0];
                        MTempMi += Matriz[ct, 1];
                        MUmi += Matriz[ct, 2];
                        MPre += Matriz[ct, 3];
                    }
                    MTempMa /= 30;
                    MTempMi /= 30;
                    MUmi /= 30;
                    MPre /= 30;
                    Console.WriteLine("=== Medias do Mês ===");
                    Console.WriteLine($"Media da Temp Maxima: {Math.Round(MTempMa, 2)}°C");
                    Console.WriteLine($"Media da Temp Minima: {Math.Round(MTempMi, 2)}°C");
                    Console.WriteLine($"Media da Umidade: {Math.Round(MUmi, 2)}%");
                    Console.WriteLine($"Media da Precipitação: {Math.Round(MPre, 2)}mm");
                    Console.WriteLine("Digite ENTER para continuar");
                    Console.ReadKey();
                    goto inicio;
                    break;
                case 2:
                    Console.Clear();
                    for (ct = 0; ct < 30; ct++)
                    {
                       
                        if (temp1 > Matriz[ct, 0]) 
                        {
                            DiaMQ = ct;
                            temp1 = Matriz[ct, 0];
                            
                        }
                    }
                    Console.WriteLine("=== Valores Extremos ===");
                    Console.WriteLine($"Dia Mais Quente: {DiaMQ+1}, Temp Max.:{Math.Round(Matriz[DiaMQ, 0], 2)}");
                    Console.WriteLine($"Dia Mais Frio: {DiaMF+1}, Temp Min.:{Math.Round(Matriz[DiaMF, 1], 2)}");
                    Console.WriteLine($"Dia Mais Chuvoso: {DiaMC + 1}, Precipitação:{Math.Round(Matriz[DiaMC, 3], 2)}");
                    Console.WriteLine("Digite ENTER para continuar");
                    Console.ReadKey();
                    goto inicio;
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                    break;
            }
        }
    }
}
