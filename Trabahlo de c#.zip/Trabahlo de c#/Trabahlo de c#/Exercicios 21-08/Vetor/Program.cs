﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vetor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] Nome = new string[5];
            double[] Nota = new double[4], media = new double[5];
            double soma, repro;
            double Apro = repro = 0;
            int ct, ct2;
            Random random = new Random();


            for (ct = 0; ct <= 4; ct++)
            {
                Console.WriteLine($"Digite o {ct + 1}º Nome: ");
                Console.WriteLine("");
                Nome[ct] = Console.ReadLine();
                soma = 0.0;
                for(ct2 = 0;ct2 <= 3; ct2++)
                {
                    Nota[ct2] = random.Next(0,10);
                    soma += Nota[ct2];
                }
                media[ct] = soma / 4;

                if (media[ct] >= 7)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Aprovado");
                    Console.WriteLine($"{Nome[ct]} Media: {media[ct]}");
                    Apro += 100;
                }
                else if (media[ct] <= 5)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Reprovado");
                    Console.WriteLine($"{Nome[ct]} Media: {media[ct]}");
                    repro += 100;
                }
                else
                {
                    Console.WriteLine("");
                    Console.WriteLine("Em Recuperação");
                    Console.WriteLine($"{Nome[ct]} Media: {media[ct]}");
                }
            }
            Console.WriteLine($"Porcentagem de Aprovados: {Apro / 5}%");
            Console.WriteLine($"Porcentagem de Reprovados: {repro / 5}%");
            Console.ReadKey();
        }
    }
}
