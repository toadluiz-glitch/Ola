﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vetor_Igual
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int VIgual = 0;
            int[] Vetor = new int[10];
            int ct, ct2;
            bool[] VF = new bool[10];
            Random random = new Random();
            for (ct = 0; ct < 10; ct++)
            {
                Vetor[ct] = random.Next(0,20);
            }
            Console.WriteLine("Vetor Original:");
            for(ct = 0;ct < 10; ct++)
            {
                Console.Write($"{Vetor[ct]}, ");
            }
            for(ct = 0;ct<10;ct++)
            {
                for (ct2 = ct+1; ct2 < 10; ct2++)
                {
                    if (Vetor[ct2] == Vetor[ct])
                    {
                        VF[ct2] = true;
                    }
                }
            }
            Console.WriteLine();
            Console.WriteLine("Vetor Sem Repetição:");
            for (ct = 0; ct < 10; ct++)
            {
                if (VF[ct] == false)
                {
                    Console.Write($"{Vetor[ct]}, ");
                }
                else
                {
                    VIgual += 1;
                }
            }
            if (VIgual != 0)
            {
                Console.WriteLine();
                Console.WriteLine("Numeros Repetidos:");
                Console.Write($"Repetiu {VIgual} Numeros do Vetor");
            }
        }
    }
}
