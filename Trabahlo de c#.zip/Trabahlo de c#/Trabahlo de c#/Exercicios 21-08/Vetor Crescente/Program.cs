﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vetor_Crescente
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int ct, ct2, temp;
            int[] Vetor = new int[50];
            Random random = new Random();
            for (ct = 0; ct < 50; ct++)
            {
            Vetor[ct] = random.Next(0,200);
            }
            Console.WriteLine("Vetor Original:");
            for (ct = 0; ct < 50; ct++)
            {
                Console.Write($", {Vetor[ct]}");
            }
            for (ct = 0; ct < 50; ct++)
            {
                int VMen = ct;
                for (ct2 = ct + 1; ct2 < 50; ct2++)
                {
                    if (Vetor[ct2] < Vetor[VMen])
                    {
                        VMen = ct2;
                    }
                }
                temp = Vetor[ct];
                Vetor[ct] = Vetor[VMen];
                Vetor[VMen] = temp;
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Vetor Ordenado: ");
            for (ct = 0; ct < 50; ct++)
            {
                Console.Write($", {Vetor[ct]}");
            }
        }
    }
}
