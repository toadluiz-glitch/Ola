﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vetor_Salario
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] Nome = new string[5];
            int ct;
            double[] Salario = new double[5];
            Random random = new Random();

            for (ct = 0;ct<=4;ct++)
            {
                Console.WriteLine("");
                Console.WriteLine($"Digite o {ct + 1}º Nome: ");
                Nome[ct] = Console.ReadLine();
                Salario[ct] = random.Next(1, 1000);
                Console.WriteLine($"Salario: {Salario[ct]}");
            }
            for (ct = 0; ct <= 4; ct++)
            {
                if(Salario[ct] > 500)
                {
                    Console.WriteLine("");
                    Console.WriteLine($"Nome: {Nome[ct]}");
                    Console.WriteLine($"Salario: {Salario[ct]}");
                }
                else if (Salario[ct] <= 200)
                {
                    Console.WriteLine("");
                    Console.WriteLine($"Nome: {Nome[ct]}");
                    Console.WriteLine($"Salario: {Salario[ct]}");
                    Salario[ct] += (Salario[ct] * 20) / 100;
                    Console.WriteLine("");
                    Console.WriteLine($"Nome: {Nome[ct]}");
                    Console.WriteLine($" Novo Salario: {Salario[ct]}");
                }
            }
            Console.ReadKey();
        }
    }
}
